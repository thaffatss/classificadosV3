
<?php
require 'pages/header.php';
require 'classes/anuncios.class.php';
require 'classes/usuarios.class.php';
require 'classes/categorias.class.php';

$u = new Usuarios();
$a = new Anuncios();
$c = new Categorias();

$filtros = array(
	'categoria' => '',
	'preco' => '',
	'estado' => ''
);
if(isset($_GET['filtros'])) {
	$filtros = $_GET['filtros'];
}

$total_anuncios = $a->getTotalAnuncios($filtros);
$total_usuarios = $u->getTotalUsuarios();

$msg_anuncio = "";
$msg_usuario = "";

// Verifica quantidade de anuncios e usuários para mostrar no plural.
if($total_anuncios > 1) {
    $msg_anuncio = "anúncios!";
} else {
    $msg_anuncio = "anúncio!";
}

if($total_anuncios == "") {
    $msg_anuncio = "nenhum anúncio!";
}
if($total_usuarios > 1) {
    $msg_usuario = "usuários cadastrados.";
} else {
    $msg_usuario = "usuário cadastrado.";
}

if($total_usuarios == "") {
    $msg_usuario = "nenhum usuário cadastrado.";
}

$p = 1;
if(isset($_GET['p']) && !empty($_GET['p'])) {
    $p = addslashes($_GET['p']);
}

// Define a quantidade de páginas. A função ceil() arredonda números quebrados.
$por_pagina = 2;
$total_paginas = ceil($total_anuncios / $por_pagina);

// Passa por parametro o numéro da página e quantidade de anúncios que será exibido.
$anuncios = $a->getUltimosAnuncios($p, $por_pagina, $filtros);
$categorias = $c->getLista();

?>
<?php require 'banner.php'; ?>
<br>
<div class="container index-container">
	<div class="jumbotron">
		<h2>Nós temos hoje <?php echo $total_anuncios; ?> <?php echo $msg_anuncio; ?></h2><br><br>
		<!-- <p class="text-muted">E mais de <?php echo $total_usuarios; ?> <?php echo $msg_usuario; ?></p> -->
		<hr>
		<p class="text-muted">Faça já seu anúncio, entre em contato com nossa equipe! </p> 
		<a href="#contact" class="btn btn-info">Contactar</a>
	</div>

	<div class="row">
	<div class="col-sm-3">
			<h4>Pesquisa Avançada</h4>
			<form method="GET">
				<div class="form-group">
					<label for="categoria">Categoria:</label>
					<select id="categoria" name="filtros[categoria]" class="form-control">
						<option></option>
						<?php foreach($categorias as $cat): ?>
						<option value="<?php echo $cat['id']; ?>" <?php echo ($cat['id']==$filtros['categoria'])?'selected="selected"':''; ?>><?php echo utf8_encode($cat['nome']); ?></option>
						<?php endforeach; ?>
					</select>
				</div>

				<div class="form-group">
					<label for="preco">Preço:</label>
					<select id="preco" name="filtros[preco]" class="form-control">
						<option></option>
						<option value="0-50" <?php echo ($filtros['preco']=='0-50')?'selected="selected"':''; ?>>R$ 0 - 50</option>
						<option value="51-100" <?php echo ($filtros['preco']=='51-100')?'selected="selected"':''; ?>>R$ 51 - 100</option>
						<option value="101-200" <?php echo ($filtros['preco']=='101-200')?'selected="selected"':''; ?>>R$ 101 - 200</option>
						<option value="201-500" <?php echo ($filtros['preco']=='201-500')?'selected="selected"':''; ?>>R$ 201 - 500</option>
					</select>
				</div>

				<div class="form-group">
					<label for="estado">Estado de Conservação:</label>
					<select id="estado" name="filtros[estado]" class="form-control">
						<option></option>
						<option value="0" <?php echo ($filtros['estado']=='0')?'selected="selected"':''; ?>>Ruim</option>
						<option value="1" <?php echo ($filtros['estado']=='1')?'selected="selected"':''; ?>>Bom</option>
						<option value="2" <?php echo ($filtros['estado']=='2')?'selected="selected"':''; ?>>Ótimo</option>
					</select>
				</div>

				<div class="form-group">
					<input type="submit" class="btn btn-info" value="Buscar" />
				</div>
			</form>

		</div>
		<div class="col-sm-9">
			<h4>Últimos Anúncios</h4>
			<table class="table table-striped table-hover">
				<tbody>
					<?php foreach($anuncios as $anuncio): ?>
					<tr class="row">
						<td>
							<?php if(!empty($anuncio['url'])): ?>
							<img src="assets/images/anuncios/<?php echo $anuncio['url']; ?>" height="200" width="300" border="0" />
							<?php else: ?>
							<img src="assets/images/default.jpg" height="50" border="0" />
							<?php endif; ?>
						</td>
						<td> 
                            <h5>
                            <a class="text-muted" href="produto.php?id=<?php echo $anuncio['id']; ?>"><?php echo $anuncio['titulo']; ?></a>
                            </h5>
                            <h6>
                                Categoria:
                            </h6>
                            <?php echo $anuncio['categoria']; ?><br><br>
                            <h6>
                                Descrição:
                            </h6>
                            <?php echo $anuncio['descricao']; ?>
                        </td>
						<td>R$ <?php echo number_format($anuncio['valor'], 2,",","."); ?></td>
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
            
            <nav aria-label="Page navigation example">
			<ul class="pagination">
				<?php for($q=1;$q<=$total_paginas;$q++): ?>
				<li class="page-item <?php echo ($p==$q)?'active':''; ?>"><a class="page-link" href="index.php?p=<?php echo $q; ?>"><?php echo $q; ?></a></li>
				<?php endfor; ?>
            </ul>
            </nav>
		</div>
	</div>
</div><br><br>
<?php require 'pages/footer.php'; ?>